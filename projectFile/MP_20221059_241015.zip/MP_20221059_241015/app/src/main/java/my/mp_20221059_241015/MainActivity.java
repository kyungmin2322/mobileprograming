package my.mp_20221059_241015;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editText, editText2;
    Button button;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.stringText);
        String stringText = editText.getText().toString();
        editText2 = findViewById(R.id.numText);
        String numText = editText2.getText().toString();

        button = findViewById(R.id.dataBtn);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 1. 명시적 인텐트 객체 생성
                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);

                // 2. put으로 데이터 전달
                intent.putExtra("id", stringText);
                intent.putExtra("num", numText);

                // 3. 대상 액티비티 실행
                startActivity(intent);

                finish();
            }
        });


    }
}