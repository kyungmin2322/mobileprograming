package my.mp_20221059_241015;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        // 4. 인텐트 전달 받기
        Intent intent = getIntent();

        String data = intent.getStringExtra("id");
        String num1 = intent.getStringExtra("num");

        TextView textView = findViewById(R.id.resultText);
        textView.setText(data + " \n" + num1);
    }
}