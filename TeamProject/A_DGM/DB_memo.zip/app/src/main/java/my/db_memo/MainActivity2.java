    package my.db_memo;

    import static android.database.sqlite.SQLiteDatabase.openDatabase;

    import android.annotation.SuppressLint;
    import android.content.Intent;
    import android.database.Cursor;
    import android.database.sqlite.SQLiteDatabase;
    import android.net.Uri;
    import android.os.Bundle;
    import android.text.Html;
    import android.text.method.LinkMovementMethod;
    import android.widget.ListView;
    import android.widget.SimpleCursorAdapter;
    import android.widget.TextView;
    import android.widget.Toast;

    import androidx.activity.EdgeToEdge;
    import androidx.appcompat.app.AppCompatActivity;
    import androidx.core.graphics.Insets;
    import androidx.core.view.ViewCompat;
    import androidx.core.view.WindowInsetsCompat;

    import java.util.regex.Matcher;
    import java.util.regex.Pattern;

    public class MainActivity2 extends AppCompatActivity {

        DBHelper helper;
        SQLiteDatabase db;
        Cursor cursor;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            EdgeToEdge.enable(this);
            setContentView(R.layout.activity_main2);

            helper = new DBHelper(this);


            // DB 객체가 닫혔을 때만 새로 열기 _ DB 이중 열기를 방지하기 위한 코드.
            if (db == null || !db.isOpen()) {
                db = helper.getWritableDatabase();
            }

            // 제대로 작동하는지 DB에 데이터 넣기용 코드
    //        helper.getWritableDatabase().execSQL("INSERT INTO notes (content, date, tag, category) " +
    //                "VALUES ('01012341234 입니다', '2024-11-20', 'novel', 'category')");

            // ListView 초기화
            @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ListView listView = findViewById(R.id.list);

            // 가끔 이중 db접근으로 오류가 나서 한번 null로 초기화함.
            cursor = null;
            try {

                if (db != null && db.isOpen()) {        // 조건문은 오류 방지용. 하드링크 생성은 content만 필요하므로 content만 사용.
                    cursor = db.rawQuery("SELECT id AS _id, content FROM notes", null);
                }

                if (cursor != null) {
                    // SimpleCursorAdapter를 사용해 ListView에 데이터 표시
                    SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                            this,
                            android.R.layout.simple_list_item_1,
                            cursor,
                            new String[]{"content"}, // DB에서 content 컬럼을 가져옴
                            new int[]{android.R.id.text1},
                            0
                    ) {
                        @Override
                        public void setViewText(android.widget.TextView v, String text) {       // 가져온 content를 클릭 가능한 하드링크로 변환
                            // 하드링크로 변환
                            String linkedText = convertToHardLinks(text);

                            // HTML로 변환
                            v.setText(Html.fromHtml(linkedText));

                            // 클릭 가능한 링크로 설정
                            v.setMovementMethod(LinkMovementMethod.getInstance());
                        }
                    };

                    // 어댑터 설정
                    listView.setAdapter(adapter);
                }
            } catch (Exception e) { // 오류 발생 추적용
                Toast.makeText(this, "쿼리 실행 중 오류: " + e.getMessage(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }

        // 문자열을 하드링크로 변환하는 함수
        @SuppressLint("NewApi")
        private String convertToHardLinks(String input) {  //input(한 메모의 전체 내용(content))에서 특정 조건에 맞는 문자열을 전부 하드링크로 변환
            // https:// 또는 www.로 시작하는 문자열이 있고 .com 또는 .net으로 끝나는 구간까지 하드링크로 변환
            Pattern urlPattern = Pattern.compile("https?://(?:www\\.)?[\\w-]+\\.(com|net)|(?:www\\.)[\\w-]+\\.(com|net)");
            //phonePattern에 내가 추출할 문자열의 조건을 기억하게함
            Matcher urlMatcher = urlPattern.matcher(input);
           // phoneMatcher에 input으로 부터 phonepattern과 일치하는 조건을 가진 문자열을 넣음
            input = urlMatcher.replaceAll(matchResult -> {
                String url = matchResult.group();
                String clickableUrl = url.startsWith("http") ? url : "https://" + url; // 클릭 시 https:// 추가
                return "<a href=\"" + clickableUrl + "\">" + url + "</a>"; // 표시 텍스트는 원래 URL 유지
            });
            //input에서 조건에 맞는 문자열들을 하드링크로 변환.

            // 11자리 숫자가 있다면 11자리 숫자 부분만 전화번호 하드링크로 변환
            Pattern phonePattern = Pattern.compile("(?<=^|[^\\d])\\d{11}(?=$|[^\\d])");
            Matcher phoneMatcher = phonePattern.matcher(input);
            input = phoneMatcher.replaceAll("<a href=\"tel:$0\">$0</a>");

    // 3-4-4 형태의 전화번호가 있다면 전화번호 부분만 하드링크로 변환
            Pattern phonePattern2 = Pattern.compile("(?<=^|[^\\d])\\d{3}-\\d{4}-\\d{4}(?=$|[^\\d])");
            Matcher phoneMatcher2 = phonePattern2.matcher(input);
            input = phoneMatcher2.replaceAll("<a href=\"tel:$0\">$0</a>");

            // 이메일 주소(@와 .com 또는 다른 도메인 확장자)가 있다면 하드링크로 변환
            Pattern emailPattern = Pattern.compile("[\\w.%+-]+@[\\w.-]+\\.(com)");
            Matcher emailMatcher = emailPattern.matcher(input);
            input = emailMatcher.replaceAll("<a href=\"mailto:$0\">$0</a>");

            return input;
            //조건에 맞는 문자열들을 하드링크로 변환한 input을 반환
        }

        @Override
        protected void onDestroy() {
            super.onDestroy();
            // DB 객체가 열려 있으면 닫기
            if (db != null && db.isOpen()) {
                db.close();
            }
            // 커서가 열려 있으면 닫기
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
    }