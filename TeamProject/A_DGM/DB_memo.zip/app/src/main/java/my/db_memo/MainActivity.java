package my.db_memo;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    DBHelper helper;
    SQLiteDatabase db;
    private Cursor cursor;
    EditText search_content, search_date, search_tag, search_category;  // 검색 및 정렬에 사용할 정보
    Button search;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        helper = new DBHelper(this);
        db = helper.getWritableDatabase(); // 앱 시작 시 열기

        search_content = findViewById(R.id.edit_content);
        search_date = findViewById(R.id.edit_date);
        search_tag = findViewById(R.id.edit_tag);
        search_category = findViewById(R.id.edit_category);
        search = findViewById(R.id.search);

        ListView list = findViewById(R.id.listView);



        });
    }



}