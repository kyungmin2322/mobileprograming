package my.db_memo;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private SQLiteDatabase database;

    // 데이터베이스 이름과 버전
    private static final String DATABASE_NAME = "memoDB"; // 데이터베이스 이름
    private static final int DATABASE_VERSION = 1; // 데이터베이스 버전

    // 테이블 이름과 컬럼 정의
    private static final String TABLE_NOTES = "notes";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_CONTENT = "content";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_TAG = "tag";
    private static final String COLUMN_CATEGORY = "category";

    // 테이블 생성 SQL 문
    private static final String SQL_CREATE_TABLE =
            "CREATE TABLE " + TABLE_NOTES + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_CONTENT + " TEXT, " +
                    COLUMN_DATE + " TEXT, " +
                    COLUMN_TAG + " TEXT, " +
                    COLUMN_CATEGORY + " TEXT);";

    // 테이블 삭제 SQL 문
    private static final String SQL_DROP_TABLE =
            "DROP TABLE IF EXISTS " + TABLE_NOTES;

    // 생성자
    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE); // 상수로 정의된 테이블 생성 SQL문 사용
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 데이터베이스 버전이 변경될 때 호출
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTES);
        onCreate(db);
    }

    public SQLiteDatabase getDatabase() {
        // 데이터베이스가 닫혀 있거나 null이면 새로 열기
        if (database == null || !database.isOpen()) {
            database = this.getWritableDatabase();
        }
        return database;
    }

    public void resetDatabase() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTES); // 기존 테이블 삭제
        onCreate(db); // 새로 테이블 생성
    }

    // 메모 삽입 메서드
    public void insertMemo(String content, String date, String tag, String category) {
        SQLiteDatabase db = this.getWritableDatabase();

        // 삽입할 값을 ContentValues 객체에 저장
        ContentValues values = new ContentValues();
        values.put(COLUMN_CONTENT, content);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_TAG, tag); // 태그는 ","로 구분된 문자열로 저장
        values.put(COLUMN_CATEGORY, category);

        // 데이터를 테이블에 삽입
        db.insert(TABLE_NOTES, null, values);
        db.close();
    }
}